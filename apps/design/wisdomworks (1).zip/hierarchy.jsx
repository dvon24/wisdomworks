// Hierarchy diagram with live add/remove animation. Pure SVG.

function Hierarchy({
  width = 980,
  height = 480,
  team,        // current team (incl. Iris first)
  externals = EXTERNALS,
  showExternals = true,
  showArcs = true,
  accent = "#6366f1",
  pendingAdd = null,    // ghost-render an agent being proposed
  pendingRemove = null, // id being faded out
  recentlyAdded = null, // id pulse-in
  onSelect,             // click handler -> agent
  focusedSubTeam = null,    // id of parent agent whose sub-team to focus
  onSubTeamOpen,            // (parentId) => void
  onSubTeamClose,           // () => void
}) {
  const cx = width / 2;
  const principal = { x: cx, y: 50 };
  const personal  = { x: cx, y: 140 };

  const specs = team.filter((a) => a.id !== "iris");
  const ghostKey = pendingAdd ? "__ghost" : null;
  const renderList = ghostKey ? [...specs, { ...pendingAdd, id: ghostKey, ghost: true }] : specs;

  const specY = 270;
  const span = width - 100;
  const positions = renderList.map((s, i) => ({
    ...s, x: 50 + (span * (i + 0.5)) / renderList.length, y: specY,
  }));
  const specById = Object.fromEntries(positions.map((s) => [s.id, s]));

  // active comm arc
  const [activeIdx, setActiveIdx] = React.useState(0);
  React.useEffect(() => {
    if (!showArcs) return;
    const t = setInterval(() => setActiveIdx((i) => (i + 1) % Math.max(1, positions.length)), 1900);
    return () => clearInterval(t);
  }, [showArcs, positions.length]);

  const exts = showExternals ? externals.map((e, i) => ({
    ...e,
    x: 60 + ((width - 120) * (i + 0.5)) / externals.length,
    y: specY + 130 + (i % 2 === 0 ? 0 : 22),
  })) : [];

  // Sub-team peer comm pulse (when focused)
  const [peerIdx, setPeerIdx] = React.useState(0);
  React.useEffect(() => {
    if (!focusedSubTeam) return;
    const t = setInterval(() => setPeerIdx((i) => i + 1), 1700);
    return () => clearInterval(t);
  }, [focusedSubTeam]);

  const arc = (x1, y1, x2, y2, lift = 30) => {
    const mx = (x1 + x2) / 2;
    const my = (y1 + y2) / 2 - lift;
    return `M ${x1} ${y1} Q ${mx} ${my} ${x2} ${y2}`;
  };

  return (
    <svg viewBox={`0 0 ${width} ${height}`} width="100%" height="100%" style={{ display: "block", overflow: "visible" }}>
      <defs>
        <radialGradient id="halo" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={accent} stopOpacity="0.4" />
          <stop offset="100%" stopColor={accent} stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* — Focused sub-team view (cross-fade) — */}
      {focusedSubTeam && (() => {
        const parent = team.find((a) => a.id === focusedSubTeam);
        if (!parent || !parent.subTeam) return null;
        const subs = parent.subTeam.agents;
        const fcx = width / 2;
        const parentY = 110;
        const ringY = 290;
        const span = width - 220;
        const subX = (j) => 110 + (span * (j + 0.5)) / subs.length;
        return (
          <g className="fade-in" key={"focus-" + focusedSubTeam}>
            {/* Back hint (rendered as foreignObject button) */}
            <foreignObject x="14" y="14" width="160" height="32">
              <button onClick={() => onSubTeamClose && onSubTeamClose()}
                      style={{ padding: "6px 12px", background: "rgba(255,255,255,0.7)", border: "1px solid rgba(20,20,30,0.12)", borderRadius: 999, fontSize: 12, color: "rgba(26,26,34,0.7)", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6, fontFamily: "inherit" }}>
                <span style={{ fontSize: 14 }}>‹</span> Back to team
              </button>
            </foreignObject>

            {/* Parent agent */}
            <circle cx={fcx} cy={parentY} r="44" fill="url(#halo)" className="breathe" />
            <circle cx={fcx} cy={parentY} r="28" fill="rgba(255,255,255,0.96)" stroke={accent} strokeWidth="2" />
            <text x={fcx} y={parentY + 5} textAnchor="middle" fontSize="14" fontWeight="600" fill="#1a1a22">{parent.label[0]}</text>
            <text x={fcx} y={parentY + 56} textAnchor="middle" fontSize="13" fontWeight="600" fill="#1a1a22">{parent.label}</text>
            <text x={fcx} y={parentY + 74} textAnchor="middle" fontSize="10" fill="rgba(26,26,34,0.55)" fontFamily="Geist Mono" letterSpacing="0.06em">{parent.role.toUpperCase()}</text>

            {/* Parent -> sub connectors */}
            {subs.map((sub, j) => (
              <path key={"l-sub-" + sub.id}
                    d={arc(fcx, parentY + 28, subX(j), ringY - 22, 30)}
                    fill="none" stroke={accent} strokeOpacity="0.3" strokeWidth="1" strokeDasharray="3 4" />
            ))}

            {/* Peer-to-peer arcs (static, faint) */}
            {subs.map((_, j) => subs.slice(j + 1).map((__, k) => {
              const j2 = j + 1 + k;
              const dist = j2 - j;
              if (dist > 2) return null;
              const sx = subX(j), sx2 = subX(j2);
              const lift = 30 + dist * 12;
              return (
                <path key={`peer-${j}-${j2}`}
                      d={`M ${sx} ${ringY - 18} Q ${(sx + sx2) / 2} ${ringY - lift} ${sx2} ${ringY - 18}`}
                      fill="none" stroke={accent} strokeOpacity="0.15" strokeWidth="0.8" strokeDasharray="2 3" />
              );
            }))}

            {/* Active peer pulse */}
            {(() => {
              const n = subs.length;
              if (n < 2) return null;
              const a = peerIdx % n;
              const b = (a + 1 + (peerIdx % 2)) % n;
              if (a === b) return null;
              const sx = subX(a), sx2 = subX(b);
              const dist = Math.abs(b - a);
              const lift = 30 + Math.min(dist, 3) * 12;
              const path = `M ${sx} ${ringY - 18} Q ${(sx + sx2) / 2} ${ringY - lift} ${sx2} ${ringY - 18}`;
              return (
                <g key={`pulse-${peerIdx}`}>
                  <path d={path} fill="none" stroke={accent} strokeWidth="1.6" strokeOpacity="0.7" />
                  <circle r="3" fill={accent}>
                    <animateMotion dur="1.4s" repeatCount="indefinite" path={path} />
                  </circle>
                </g>
              );
            })()}

            {/* Active manager <-> sub-agent pulse */}
            {(() => {
              const n = subs.length;
              const idx = peerIdx % n;
              const path = arc(fcx, parentY + 28, subX(idx), ringY - 22, 38);
              return (
                <g key={`mgr-${peerIdx}`}>
                  <path d={path} fill="none" stroke={accent} strokeWidth="2" opacity="0.85" />
                  <circle r="3.5" fill={accent}>
                    <animateMotion dur="1.4s" repeatCount="indefinite" path={path} />
                  </circle>
                </g>
              );
            })()}

            {/* Sub-agents */}
            {subs.map((sub, j) => {
              const sx = subX(j), sy = ringY;
              return (
                <g key={sub.id} className="pop-in" style={{ animationDelay: (180 + j * 70) + "ms", cursor: onSelect ? "pointer" : "default" }}
                   onClick={() => onSelect && onSelect(sub)}>
                  <circle cx={sx} cy={sy} r="22" fill="rgba(255,255,255,0.96)" stroke={accent} strokeOpacity="0.4" strokeWidth="1.2" />
                  <text x={sx} y={sy + 5} textAnchor="middle" fontSize="13" fontWeight="600" fill="#1a1a22" style={{ pointerEvents: "none" }}>{sub.label[0]}</text>
                  <text x={sx} y={sy + 44} textAnchor="middle" fontSize="11" fontWeight="500" fill="#1a1a22" style={{ pointerEvents: "none" }}>{sub.label}</text>
                  <text x={sx} y={sy + 60} textAnchor="middle" fontSize="9" fill="rgba(26,26,34,0.5)" fontFamily="Geist Mono" letterSpacing="0.05em" style={{ pointerEvents: "none" }}>{sub.role.toUpperCase()}</text>
                  <g style={{ pointerEvents: "none" }}>
                    <rect x={sx - 24} y={sy + 70} width="48" height="14" rx="7" fill={accent} fillOpacity="0.12" stroke={accent} strokeOpacity="0.4" strokeWidth="0.8" />
                    <text x={sx} y={sy + 80} textAnchor="middle" fontSize="8.5" fontFamily="Geist Mono" fontWeight="500" fill={accent} letterSpacing="0.06em">{sub.tier.toUpperCase()}</text>
                  </g>
                </g>
              );
            })}
          </g>
        );
      })()}

      {!focusedSubTeam && (<>

      {/* principal -> personal */}
      <line x1={principal.x} y1={principal.y + 22} x2={personal.x} y2={personal.y - 30}
            stroke="rgba(20,20,30,0.28)" strokeWidth="1.2" />

      {/* personal -> specialists */}
      {positions.map((s) => (
        <path key={"l1-" + s.id}
              d={arc(personal.x, personal.y + 30, s.x, s.y - 18, 30)}
              fill="none"
              stroke={s.ghost ? accent : "rgba(20,20,30,0.18)"}
              strokeWidth={s.ghost ? 1.4 : 1}
              strokeDasharray={s.ghost ? "4 4" : "none"}
              opacity={s.id === pendingRemove ? 0.25 : 1}
              style={{ transition: "opacity .4s" }} />
      ))}

      {/* specialists -> externals */}
      {exts.map((e) => e.links.map((sid) => {
        const s = specById[sid];
        if (!s) return null;
        return (
          <path key={"l2-" + e.id + "-" + sid}
                d={arc(s.x, s.y + 14, e.x, e.y - 8, 16)}
                fill="none"
                stroke="rgba(20,20,30,0.13)"
                strokeWidth="0.8"
                strokeDasharray="3 4" />
        );
      }))}

      {/* live comm arc */}
      {showArcs && positions[activeIdx] && !positions[activeIdx].ghost && (
        <g>
          <path d={arc(personal.x, personal.y + 30, positions[activeIdx].x, positions[activeIdx].y - 18, 38)}
                fill="none" stroke={accent} strokeWidth="2" opacity="0.85" />
          <circle r="3.5" fill={accent}>
            <animateMotion dur="1.4s" repeatCount="indefinite"
              path={arc(personal.x, personal.y + 30, positions[activeIdx].x, positions[activeIdx].y - 18, 38)} />
          </circle>
        </g>
      )}

      {/* Principal */}
      <g>
        <circle cx={principal.x} cy={principal.y} r="22" fill="rgba(255,255,255,0.88)" stroke="rgba(20,20,30,0.2)" />
        <text x={principal.x} y={principal.y + 4} textAnchor="middle" fontSize="11" fontWeight="600" fill="#1a1a22">{TENANT.user.initials}</text>
        <text x={principal.x} y={principal.y + 38} textAnchor="middle" fontSize="9" fill="rgba(26,26,34,0.55)" fontFamily="Geist Mono">{TENANT.user.first.toUpperCase()} · {TENANT.user.role.toUpperCase()}</text>
      </g>

      {/* Iris */}
      <g style={{ cursor: onSelect ? "pointer" : "default" }} onClick={() => onSelect && onSelect(team.find((a) => a.id === "iris"))}>
        <circle cx={personal.x} cy={personal.y} r="38" fill="url(#halo)" className="breathe" />
        <circle cx={personal.x} cy={personal.y} r="28" fill="rgba(255,255,255,0.96)" stroke={accent} strokeOpacity="0.4" strokeWidth="1" />
        <WisdomMarkInline cx={personal.x} cy={personal.y} scale={0.46} accent={accent} satellite={accent} animate />
        <text x={personal.x} y={personal.y + 46} textAnchor="middle" fontSize="10" fontWeight="600" fill="#1a1a22" style={{ pointerEvents: "none" }}>Iris</text>
        <text x={personal.x} y={personal.y + 60} textAnchor="middle" fontSize="9" fill={accent} fontFamily="Geist Mono" fontWeight="500" letterSpacing="0.06em" style={{ pointerEvents: "none" }}>OPUS</text>
      </g>

      {/* Specialists */}
      {positions.map((s, i) => {
        const isActive = i === activeIdx && showArcs && !s.ghost;
        const dotColor = s.status === "ok" ? "#2cb070" : s.status === "warn" ? "#d99b3b" : s.status === "bad" ? "#c84545" : "#888";
        const isRemoving = s.id === pendingRemove;
        const isAdded = s.id === recentlyAdded;
        const className = s.ghost || isAdded ? "pop-in" : isRemoving ? "fade-out" : "";
        return (
          <g key={s.id} className={className} opacity={s.ghost ? 0.7 : 1}
             style={{ cursor: onSelect && !s.ghost ? "pointer" : "default" }}
             onClick={() => !s.ghost && onSelect && onSelect(team.find((a) => a.id === s.id))}>
            {isActive && <circle cx={s.x} cy={s.y} r="22" fill={accent} opacity="0.18" />}
            <circle cx={s.x} cy={s.y} r="14"
                    fill={s.ghost ? "rgba(99,102,241,0.18)" : "rgba(255,255,255,0.94)"}
                    stroke={isActive ? accent : s.ghost ? accent : "rgba(20,20,30,0.18)"}
                    strokeWidth={isActive || s.ghost ? 1.6 : 1}
                    strokeDasharray={s.ghost ? "3 3" : "none"} />
            {!s.ghost && <circle cx={s.x + 9} cy={s.y - 9} r="3" fill={dotColor} />}
            <text x={s.x} y={s.y + 4} textAnchor="middle" fontSize="10" fontWeight="600" fill={s.ghost ? accent : "#1a1a22"} style={{ pointerEvents: "none" }}>
              {s.ghost ? "+" : s.label[0]}
            </text>
            <text x={s.x} y={s.y + 30} textAnchor="middle" fontSize="10" fontWeight="500" fill="#1a1a22" style={{ pointerEvents: "none" }}>{s.label}</text>
            <text x={s.x} y={s.y + 43} textAnchor="middle" fontSize="9" fill="rgba(26,26,34,0.5)" fontFamily="Geist Mono" style={{ pointerEvents: "none" }}>
              {s.role.toUpperCase()}
            </text>
            {!s.ghost && s.tier && (
              <g style={{ pointerEvents: "none" }}>
                <rect x={s.x - 26} y={s.y + 49} width="52" height="14" rx="7"
                      fill={accent} fillOpacity="0.12"
                      stroke={accent} strokeOpacity="0.4" strokeWidth="0.8" />
                <text x={s.x} y={s.y + 59} textAnchor="middle" fontSize="8.5"
                      fontFamily="Geist Mono" fontWeight="500"
                      fill={accent} letterSpacing="0.06em">
                  {s.tier.toUpperCase()}
                </text>
              </g>
            )}
            {!s.ghost && s.subTeam && (
              <g style={{ cursor: "pointer" }}
                 onClick={(e) => { e.stopPropagation(); onSubTeamOpen && onSubTeamOpen(s.id); }}>
                <circle cx={s.x + 14} cy={s.y - 14} r="9" fill={accent} stroke="white" strokeWidth="1.5">
                  <animate attributeName="r" values="9;10.5;9" dur="2s" repeatCount="indefinite" />
                </circle>
                <text x={s.x + 14} y={s.y - 11} textAnchor="middle" fontSize="9" fontWeight="700" fill="white" style={{ pointerEvents: "none" }}>{s.subTeam.count}</text>
              </g>
            )}
          </g>
        );
      })}

      {/* Externals */}
      {exts.map((e) => (
        <g key={e.id} opacity="0.85">
          <rect x={e.x - 30} y={e.y - 9} width="60" height="18" rx="9"
                fill="rgba(255,255,255,0.62)" stroke="rgba(20,20,30,0.12)" />
          <text x={e.x} y={e.y + 4} textAnchor="middle" fontSize="9" fill="rgba(26,26,34,0.7)" fontFamily="Geist Mono">{e.label.toUpperCase()}</text>
        </g>
      ))}
      </>)}
    </svg>
  );
}

window.Hierarchy = Hierarchy;
